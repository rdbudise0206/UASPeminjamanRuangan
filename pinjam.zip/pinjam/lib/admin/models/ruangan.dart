class Ruangan {
  final int? idRuangan;
  final String kdRuangan;
  final String namaRuangan;
  final String namaGedung;
  final int lantai;
  final String statusRuangan;

  Ruangan({
    this.idRuangan,
    required this.kdRuangan,
    required this.namaRuangan,
    required this.namaGedung,
    required this.lantai,
    required this.statusRuangan,
  });

  factory Ruangan.fromJson(Map<String, dynamic> json) {
    print('Parsing JSON: $json'); // Debug print

    // Handle the ID field
    int? parsedId;
    if (json['id_ruangan'] != null) {
      try {
        parsedId = int.parse(json['id_ruangan'].toString());
      } catch (e) {
        print('Error parsing id_ruangan: $e');
      }
    }

    return Ruangan(
      idRuangan: parsedId,
      kdRuangan: json['kd_ruangan']?.toString() ?? '',
      namaRuangan: json['nama_ruangan']?.toString() ?? '',
      namaGedung: json['nama_gedung']?.toString() ?? '',
      lantai: json['lantai'] != null
          ? int.tryParse(json['lantai'].toString()) ?? 0
          : 0,
      statusRuangan: json['status_ruangan']?.toString() ?? 'tersedia',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id_ruangan': idRuangan,
      'kd_ruangan': kdRuangan,
      'nama_ruangan': namaRuangan,
      'nama_gedung': namaGedung,
      'lantai': lantai,
      'status_ruangan': statusRuangan,
    };
  }

  @override
  String toString() {
    return 'Ruangan{idRuangan: $idRuangan, kdRuangan: $kdRuangan, namaRuangan: $namaRuangan, '
        'namaGedung: $namaGedung, lantai: $lantai, statusRuangan: $statusRuangan}';
  }
}